﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MVC_FinalProject.DAL;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.BLL
{
    public class CourseEnrollManager
    {
        private CourseEnrollGateway courseEnrollGateway = new CourseEnrollGateway();

        public int SaveEnrollCourse(EnrollCourse enrollCourse)
        {
            if (IsExistCourseEnroll(enrollCourse))
            {
                throw new Exception("This Student already enroll this course");
            }
            return courseEnrollGateway.SaveEnrollCourse(enrollCourse);
        }

        private bool IsExistCourseEnroll(EnrollCourse enrollCourse)
        {
            return courseEnrollGateway.IsExistCourseEnroll(enrollCourse);
        }

        public List<EnrollCourse> AllEnrollCourseInfo()
        {
            return courseEnrollGateway.AllEnrollCourseInfo();
        }
    }
}