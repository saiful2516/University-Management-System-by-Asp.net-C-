﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MVC_FinalProject.DAL;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.BLL
{
    public class CourseManager
    {
        public int SaveCourse(Course course)
        {
            if (IsCourseCodeExist(course.CourseCode))
            {
                throw new Exception("Course Code Already Exist");
            }

            if (IsCourseNameExist(course.CourseName))
            {
                throw new Exception("Course Name Already Exist");
            }
            CourseGateway courseGateway = new CourseGateway();
            return courseGateway.SaveCourse(course);
        }

        private bool IsCourseNameExist(string courseName)
        {
            CourseGateway courseGateway = new CourseGateway();
            return courseGateway.IsCourseNameExist(courseName);
        }

        private bool IsCourseCodeExist(string courseCode)
        {
            CourseGateway courseGateway = new CourseGateway();
            return courseGateway.IsCourseCodeExist(courseCode);
        }

        public List<Course> CourseList()
        {
            CourseGateway courseGateway = new CourseGateway();
            return courseGateway.CourseList();
        }
    }
}