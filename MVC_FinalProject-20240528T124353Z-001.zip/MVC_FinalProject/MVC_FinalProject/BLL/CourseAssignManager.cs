﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MVC_FinalProject.DAL;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.BLL
{
    public class CourseAssignManager
    {
        public int SaveAssignCourse(CourseAssign courseAssign)
        {
            if (IsCourseAssign(courseAssign.CourseId))
            {
                throw new Exception("This Course Already Assign");
            }
            CourseAssignGateway courseAssignGateway = new CourseAssignGateway();
            return courseAssignGateway.SaveAssignCourse(courseAssign);
        }

        private bool IsCourseAssign(int courseId)
        {
            CourseAssignGateway courseAssignGateway = new CourseAssignGateway();
            return courseAssignGateway.IsCourseAssign(courseId);
        }


        public List<CourseAssign> GetCourseList()
        {
            CourseAssignGateway courseAssignGateway = new CourseAssignGateway();
            return courseAssignGateway.GetCourseList();
        }

        public List<CourseAssign> SearchCourseByDepartment(int departmentId)
        {
            CourseAssignGateway courseAssignGateway = new CourseAssignGateway();
            return courseAssignGateway.SearchCourseByDepartment(departmentId);
        }

        public int UnAssignAllCourse()
        {
            if (CheckExistAssignCourse() == false)
            {
                throw new Exception("There are no course found to unassign");
            }
            CourseAssignGateway courseAssignGateway = new CourseAssignGateway();
            return courseAssignGateway.UnAssignAllCourse();
        }

        private bool CheckExistAssignCourse()
        {
            CourseAssignGateway courseAssignGateway = new CourseAssignGateway();
            return courseAssignGateway.CheckExistAssignCourse();
        }
    }
}