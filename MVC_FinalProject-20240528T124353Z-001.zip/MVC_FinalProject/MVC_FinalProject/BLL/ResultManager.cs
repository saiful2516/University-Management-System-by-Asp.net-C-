﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MVC_FinalProject.DAL;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.BLL
{
    public class ResultManager
    {
        public int SaveResult(Result result)
        {
            if (CheckDuplicateResult(result))
            {
                throw new Exception("This Course Result Already Submitted");
            }
            ResultGateway resultGateway = new ResultGateway();
            return resultGateway.SaveResult(result);
        }

        private bool CheckDuplicateResult(Result result)
        {
            ResultGateway resultGateway = new ResultGateway();
            return resultGateway.CheckDuplicateResult(result);
        }
    }
}