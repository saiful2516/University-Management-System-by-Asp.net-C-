﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MVC_FinalProject.DAL;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.BLL
{
    public class ClassRoomManager
    {
        
        private ClassRoomGateway classRoomGateway =new ClassRoomGateway();
        public List<ClassRoom> RoomList()
        {
            return classRoomGateway.RoomList();
        }

        public int AllocateNewClassRoom(ClassRoom classRoom)
        {
            if (CheckDuplicateAllocation(classRoom))
            {
                throw new Exception("Sorry...Duplicate Class Allocation Found. Try Again");
            }

            if (CheckCourseDuplicationByDay(classRoom))
            {
                throw new Exception("Sorry...In this day this course is already assign");
            }

            if (CheckRoomDayTimeDuplication(classRoom))
            {
                throw new Exception("Sorry...In this time this room is already assign");
            }
            if (CheckDayTimeDuration(classRoom))
            {
                throw new Exception("Sorry...In this time this room is already assign");
            }
            return classRoomGateway.AllocateNewClassRoom(classRoom);
        }

        private bool CheckDayTimeDuration(ClassRoom classRoom)
        {
            return classRoomGateway.CheckDayTimeDuration(classRoom);
        }

        private bool CheckRoomDayTimeDuplication(ClassRoom classRoom)
        {
            return classRoomGateway.CheckRoomDayTimeDuplication(classRoom);
        }

        private bool CheckCourseDuplicationByDay(ClassRoom classRoom)
        {
            return classRoomGateway.CheckCourseDuplicationByDay(classRoom);
        }

        private bool CheckDuplicateAllocation(ClassRoom classRoom)
        {
            return classRoomGateway.CheckDuplicateAllocation(classRoom);
        }

        public List<ClassRoom> TimeScheduleList()
        {
            return classRoomGateway.TimeScheduleList();
        }

        public decimal UnassignClassRoom()
        {
            return classRoomGateway.UnassignClassRoom();
        }

        public List<ClassRoom> DayList()
        {
            return classRoomGateway.DayList();
        }

        public List<ClassRoom> GetAllocateRoomInfoByDepartment(int departmentId)
        {
            return classRoomGateway.GetAllocateRoomInfoByDepartment(departmentId);
        }
    }
}