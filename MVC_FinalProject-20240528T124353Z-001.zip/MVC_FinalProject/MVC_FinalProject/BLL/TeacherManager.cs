﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MVC_FinalProject.DAL;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.BLL
{
    public class TeacherManager
    {
        public int SaveTeacher(Teacher teacher)
        {
            if (IsEmailExist(teacher.Email))
            {
                throw new Exception("Duplicate Email Address Found");
            }
            
            TeacherGateway teacherGateway = new TeacherGateway();
            return teacherGateway.SaveTeacher(teacher);
        }

        private bool IsEmailExist(string Email)
        {
            TeacherGateway teacherGateway=new TeacherGateway();
            return teacherGateway.IsEmailExist(Email);
        }



        public List<Teacher> GetDesigntatinoList()
        {
           TeacherGateway teacherGateway=new TeacherGateway();
            return teacherGateway.GetDesigntatinoList();
        }
   

        public List<Department> GetDepartmentList()
        {
            DepartmentGateway departmentGateway = new DepartmentGateway();
            return departmentGateway.GetDepartmentList();
        }


        public List<Teacher> GetAllTeacher()
        {
            TeacherGateway teacherGateway = new TeacherGateway();
            return teacherGateway.GetAllTeacher();
        }
    }
}