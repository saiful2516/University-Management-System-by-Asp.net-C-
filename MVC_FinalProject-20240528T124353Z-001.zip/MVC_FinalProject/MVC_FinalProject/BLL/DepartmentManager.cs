﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MVC_FinalProject.DAL;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.BLL
{
    public class DepartmentManager
    {
        public int SaveDepartment(Department department)
        {
            if (IsDeptNameExist(department.DepartmentName))
            {
                throw new Exception("Department Name Already Exist");
            }
            if (IsDeptCodeExist(department.DepartmentCode))
            {
                throw new Exception("Department Code Already Exist");
            }

            DepartmentGateway departmentGateway = new DepartmentGateway();
            return departmentGateway.SaveDepartment(department);
        }

        private bool IsDeptNameExist(string departmentName)
        {
            DepartmentGateway departmentGateway = new DepartmentGateway();
            return departmentGateway.IsDeptNameExist(departmentName);
        }

        private bool IsDeptCodeExist(string departmentCode)
        {
            DepartmentGateway departmentGateway = new DepartmentGateway();
            return departmentGateway.IsDeptCodeExist(departmentCode);
        }

        public List<Department> GetDepartmentList()
        {
            DepartmentGateway departmentGateway = new DepartmentGateway();
            return departmentGateway.GetDepartmentList();
        }

        public List<Semester> GetSemesterList()
        {
            DepartmentGateway departmentGateway = new DepartmentGateway();
            return departmentGateway.GetSemesterList();
        }


        public Department GetDepartmentCodeById(int deptId)
        {
            DepartmentGateway departmentGateway = new DepartmentGateway();
            return departmentGateway.GetDepartmentCodeById(deptId);
        }
    }
}