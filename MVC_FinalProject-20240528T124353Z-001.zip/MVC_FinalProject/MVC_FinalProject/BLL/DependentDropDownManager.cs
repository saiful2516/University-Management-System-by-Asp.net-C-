﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MVC_FinalProject.DAL;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.BLL
{
    public class DependentDropDownManager
    {
        public List<AssignCourseWithTeacher> GetTecherListByDepartmentId(int departmentId)
        {
            DependentDropDownGateway dependentDropDownGateway = new DependentDropDownGateway();
            return dependentDropDownGateway.GetTecherListByDepartmentId(departmentId);
        }

        public List<AssignCourseWithTeacher> GetAssignCourseListByDepartmentId(int departmentId)
        {
            DependentDropDownGateway dependentDropDownGateway = new DependentDropDownGateway();
            return dependentDropDownGateway.GetAssignCourseListByDepartmentId(departmentId);
        }

        public List<Course> GetCourseListByDepartmentId(int departmentId)
        {
            DependentDropDownGateway dependentDropDownGateway = new DependentDropDownGateway();
            return dependentDropDownGateway.GetCourseListByDepartmentId(departmentId);
        }

        public List<AssignCourseWithTeacher> GetTeacherCreditByTeacherId(int teacherId)
        {
            DependentDropDownGateway dependentDropDownGateway = new DependentDropDownGateway();
            return dependentDropDownGateway.GetTeacherCreditByTeacherId(teacherId);
        }

        public List<Course> GetCourseInfoByCourseId(int courseId)
        {
            DependentDropDownGateway dependentDropDownGateway = new DependentDropDownGateway();
            return dependentDropDownGateway.GetCourseInfoByCourseId(courseId);
        }

        public List<Student> GetStudentInfoByRegNo(string registrationNo)
        {
            DependentDropDownGateway dependentDropDownGateway = new DependentDropDownGateway();
            return dependentDropDownGateway.GetStudentInfoByRegNo(registrationNo);
        }

        public List<EnrollCourse> GetStudentCourseIdByRegNo(string registrationNo)
        {
            DependentDropDownGateway dependentDropDownGateway = new DependentDropDownGateway();
            return dependentDropDownGateway.GetStudentCourseIdByRegNo(registrationNo);
        }

        public List<EnrollCourse> GetDepartmentCourseIdByStudentRegNo(string registrationNo)
        {
            DependentDropDownGateway dependentDropDownGateway = new DependentDropDownGateway();
            return dependentDropDownGateway.GetDepartmentCourseIdByStudentRegNo(registrationNo);
        }

        public List<Result> GetResultByRegNo(string registrationNo)
        {
            DependentDropDownGateway dependentDropDownGateway = new DependentDropDownGateway();
            return dependentDropDownGateway.GetResultByRegNo(registrationNo);
        }
    }
}