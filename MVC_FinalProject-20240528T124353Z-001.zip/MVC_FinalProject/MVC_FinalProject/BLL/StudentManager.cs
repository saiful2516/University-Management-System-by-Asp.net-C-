﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MVC_FinalProject.DAL;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.BLL
{
    public class StudentManager
    {
        StudentGateway studentGateway = new StudentGateway();
        public List<Student> GetAllStudents()
        {
            return studentGateway.GetAllStudents();
        }

        public int SaveNewStudent(Student student)
        {
            return studentGateway.SaveNewStudent(student);
        }

        public bool IfEmailExist(string studentEmail)
        {
            return studentGateway.IfEmailExist(studentEmail);
        }

        public int GetStudentCountId(Student student)
        {
            return studentGateway.GetStudentCountId(student);
        }

        public int UpdateStudentCounter(int regNo, Student student)
        {
            return studentGateway.UpdateStudentCounter(regNo, student);
        }

        public int AddStudentCounter(Student student)
        {
            return studentGateway.AddStudentCounter(student);
        }

    }
}