﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_FinalProject.BLL;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.Controllers
{
    public class CourseEnrollController : Controller
    {
        StudentManager studentManager = new StudentManager();
        CourseEnrollManager courseEnrollManager = new CourseEnrollManager();
        public ActionResult Index()
        {
            ViewBag.StudentList = studentManager.GetAllStudents();
            ViewBag.EnrollList = courseEnrollManager.AllEnrollCourseInfo();
            return View();
        }

        [HttpPost]
        public ActionResult Index(EnrollCourse enrollCourse)
        {
            ViewBag.StudentList = studentManager.GetAllStudents();
            ViewBag.EnrollList = courseEnrollManager.AllEnrollCourseInfo();
            try
            {
                if (courseEnrollManager.SaveEnrollCourse(enrollCourse) > 0)
                {
                    ModelState.Clear();
                    ViewBag.EnrollList = courseEnrollManager.AllEnrollCourseInfo();
                    ViewBag.Message = "New Course Enroll Successfully";
                }
                else
                {
                    ViewBag.EnrollList = courseEnrollManager.AllEnrollCourseInfo();
                    ViewBag.Errormessage = "Failed to enroll new course";
                }
            }
            catch (Exception e)
            {
                ViewBag.Errormessage = e.Message;
            }
            return View();
        }
	}
}