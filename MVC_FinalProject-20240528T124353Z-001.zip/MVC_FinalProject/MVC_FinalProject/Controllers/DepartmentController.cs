﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_FinalProject.BLL;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.Controllers
{
    public class DepartmentController : Controller
    {
        DepartmentManager departmentManager = new DepartmentManager();
        public ActionResult Index()
        {
            ViewBag.DepartmentList = departmentManager.GetDepartmentList();
            return View();
        }

        [HttpPost]
        public ActionResult Index(Department department)
        {
            ViewBag.DepartmentList = departmentManager.GetDepartmentList();
            try
            {
                if(departmentManager.SaveDepartment(department) > 0)
                {
                    ModelState.Clear();
                    ViewBag.DepartmentList = departmentManager.GetDepartmentList();
                    ViewBag.Message = "Save New Department";
                }
                else
                {
                    ViewBag.Errormessage = "New Department not saved successfully";
                }
            }
            catch (Exception e)
            {
                ViewBag.Errormessage = e.Message;
            }

            return View();
        }

      
        public ActionResult ViewDepartment()
        {
            ViewBag.DepartmentList = departmentManager.GetDepartmentList();
            return View();
        }

        

        
	}
}