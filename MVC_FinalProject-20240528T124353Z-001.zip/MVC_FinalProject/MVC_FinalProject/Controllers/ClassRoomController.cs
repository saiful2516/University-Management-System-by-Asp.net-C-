﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_FinalProject.BLL;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.Controllers
{
    public class ClassRoomController : Controller
    {
        DepartmentManager departmentManager = new DepartmentManager();
        ClassRoomManager classRoomManager = new ClassRoomManager();
        public ActionResult Index()
        {
            ViewBag.DepartmentList = departmentManager.GetDepartmentList();
            ViewBag.RoomList = classRoomManager.RoomList();
            ViewBag.DayList = classRoomManager.DayList();
            return View();
        }

        [HttpPost]
        public ActionResult Index(ClassRoom classRoom)
        {
            ViewBag.DepartmentList = departmentManager.GetDepartmentList();
            ViewBag.RoomList = classRoomManager.RoomList();
            ViewBag.DayList = classRoomManager.DayList();
            try
            {
                classRoom.TimeFrom = DateTime.Parse(classRoom.TimeFrom.ToString());
                classRoom.TimeTo = DateTime.Parse(classRoom.TimeTo.ToString());
                if (classRoomManager.AllocateNewClassRoom(classRoom) > 0)
                {
                    ModelState.Clear();
                    ViewBag.Message = "New Class Room Allocate";
                }
                else
                {
                    ViewBag.ErrorMessage = "Class Room Allocate Not Allocate Successfuuly";
                }
            }
            catch (Exception e)
            {
                ViewBag.ErrorMessage = e.Message;
            }
            return View();
        }

        public ActionResult ViewRoomSchedule()
        {
            ViewBag.DepartmentList = departmentManager.GetDepartmentList();
            ViewBag.TimeSchedule = classRoomManager.TimeScheduleList();
            return View();
        }
        [HttpPost]
        public ActionResult ViewRoomSchedule(ClassRoom classRoom)
        {
            ViewBag.DepartmentList = departmentManager.GetDepartmentList();
            ViewBag.TimeSchedule = classRoomManager.TimeScheduleList();
            return View();
        }

        public JsonResult GetAllocateRoomInfoByDepartment(int departmentId)
        {
            var schedulelist = classRoomManager.GetAllocateRoomInfoByDepartment(departmentId);
            return Json(schedulelist, JsonRequestBehavior.AllowGet);
        }

        public ActionResult UnassignClassRoom()
        {
            return View();
        }
        [HttpPost]
        public ActionResult UnassignClassRoom(FormCollection form)
        {
            try
            {
                if (classRoomManager.UnassignClassRoom() > 0)
                {
                    ViewBag.Message = "Successfully All Class Rooms Are Un-Allocate";
                }
                else
                {
                    ViewBag.Errormessage = "Failed to Un-Allocate class rooms";
                }
            }
            catch (Exception e)
            {

                ViewBag.Errormessage = e.Message;
            }
            return View();
        }
       
	}
}