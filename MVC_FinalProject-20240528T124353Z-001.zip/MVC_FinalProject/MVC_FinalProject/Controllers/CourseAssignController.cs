﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Web;
using System.Web.Mvc;
using MVC_FinalProject.BLL;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.Controllers
{
    public class CourseAssignController : Controller
    {
        DepartmentManager departmentManager = new DepartmentManager();
        CourseAssignManager courseAssignManager = new CourseAssignManager();
        public ActionResult Index()
        {
            ViewBag.DepartmentList = departmentManager.GetDepartmentList();
            return View();
        }

        [HttpPost]
        public ActionResult Index(CourseAssign courseAssign)
        {
            ViewBag.DepartmentList = departmentManager.GetDepartmentList();
            try
            {
                if (courseAssignManager.SaveAssignCourse(courseAssign) > 0)
                {
                    ModelState.Clear();
                    ViewBag.Message = "New Course Assign successfully";
                }
                else
                {
                    ViewBag.Errormessage = "New Course Not Assign successfully";
                }
            }
            catch (Exception e)
            {

                ViewBag.Errormessage = e.Message; //"New Course Not Assign successfully"
            }
            return View();
        }

        public ActionResult SearchCourseStatics()
        {
            ViewBag.DepartmentList = departmentManager.GetDepartmentList();
            ViewBag.CourseList = courseAssignManager.GetCourseList();
            return View();
        }

        [HttpPost]
        public ActionResult SearchCourseStatics(FormCollection form)
        {
            ViewBag.DepartmentList = departmentManager.GetDepartmentList();
            
            try
            {
                int DepartmentId = Convert.ToInt32(form["DepartmentId"]);
                ViewBag.CourseList = courseAssignManager.SearchCourseByDepartment(DepartmentId);
            }
            catch (Exception e)
            {

                ViewBag.Errormessage = e.Message;
            }
            return View();
        }

        public JsonResult GetAssignCourseInfoByDepartment(int departmentId)
        {
            var schedulelist = courseAssignManager.SearchCourseByDepartment(departmentId);
            return Json(schedulelist, JsonRequestBehavior.AllowGet);
        }


        public ActionResult UnAssignCourses()
        {
            return View();
        }

        [HttpPost]
        public ActionResult UnAssignCourses(FormCollection form)
        {
            try
            {
                if (courseAssignManager.UnAssignAllCourse() > 0)
                {
                    ViewBag.Message = "Successfully All Courses Are Un-Assign";
                }
                else
                {
                    ViewBag.Errormessage = "All Courses Are Not Un-Assign";
                }
            }
            catch (Exception e)
            {

                ViewBag.Errormessage = e.Message;
            }
            return View();
        }
	}
}