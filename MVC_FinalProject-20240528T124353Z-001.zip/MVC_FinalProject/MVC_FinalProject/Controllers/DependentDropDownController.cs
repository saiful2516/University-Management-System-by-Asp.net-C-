﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_FinalProject.BLL;

namespace MVC_FinalProject.Controllers
{
    public class DependentDropDownController : Controller
    {
        DependentDropDownManager dependentDropDownManager= new DependentDropDownManager();
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult GetTecherListByDepartmentId(int departmentId)
        {
            var teacherList = dependentDropDownManager.GetTecherListByDepartmentId(departmentId);
            return Json(teacherList, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetAssignCourseListByDepartmentId(int departmentId)
        {
            var teacherList = dependentDropDownManager.GetAssignCourseListByDepartmentId(departmentId);
            return Json(teacherList, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetCourseListByDepartmentId(int departmentId)
        {
            var teacherList = dependentDropDownManager.GetCourseListByDepartmentId(departmentId);
            return Json(teacherList, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetTeacherCreditByTeacherId(int teacherId)
        {
            var teacherInfo = dependentDropDownManager.GetTeacherCreditByTeacherId(teacherId);
            return Json(teacherInfo, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetCourseInfoByCourseId(int courseId)
        {
            var teacherInfo = dependentDropDownManager.GetCourseInfoByCourseId(courseId);
            return Json(teacherInfo, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetDepartmentCourseIdByStudentRegNo(string registrationNo)
        {
            var teacherInfo = dependentDropDownManager.GetDepartmentCourseIdByStudentRegNo(registrationNo);
            return Json(teacherInfo, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetStudentInfoByRegNo(string registrationNo)
        {
            var teacherInfo = dependentDropDownManager.GetStudentInfoByRegNo(registrationNo);
            return Json(teacherInfo, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetStudentCourseIdByRegNo(string registrationNo)
        {
            var teacherInfo = dependentDropDownManager.GetStudentCourseIdByRegNo(registrationNo);
            return Json(teacherInfo, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetResultByRegNo(string registrationNo)
        {
            var teacherInfo = dependentDropDownManager.GetResultByRegNo(registrationNo);
            return Json(teacherInfo, JsonRequestBehavior.AllowGet);
        }
    }
}