﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_FinalProject.BLL;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.Controllers
{
    public class SaveTeacherController : Controller
    {
        TeacherManager teacherManager=new TeacherManager();
        DepartmentManager departmentManager = new DepartmentManager();
        public ActionResult SaveTeacher()
        {
            ViewBag.DesignationList = teacherManager.GetDesigntatinoList();
            ViewBag.DepartmentList = teacherManager.GetDepartmentList();
            ViewBag.TeacherList = teacherManager.GetAllTeacher();
            return View();
            
        }


        [HttpPost]
        public ActionResult SaveTeacher(Teacher teacher)
        {
            ViewBag.DesignationList = teacherManager.GetDesigntatinoList();
            ViewBag.DepartmentList = teacherManager.GetDepartmentList();
            ViewBag.TeacherList = teacherManager.GetAllTeacher();
            try
            {
                if (teacherManager.SaveTeacher(teacher) > 0)
                {
                    ModelState.Clear();
                    ViewBag.TeacherList = teacherManager.GetAllTeacher();
                    ViewBag.Message = "New Teacher Profile Created";
                }
                else
                {
                    ViewBag.Errormessage = "Teacher Profile Not Created";
                }
            }
            catch (Exception e)
            {

                ViewBag.Errormessage = e.Message;
            }
            return View();
        }
	}
}