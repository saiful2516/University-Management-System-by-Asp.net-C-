﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_FinalProject.BLL;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.Controllers
{
    public class CourseController : Controller
    {
        CourseManager courseManager = new CourseManager();
        DepartmentManager departmentManager = new DepartmentManager();
        public ActionResult Index()
        {
            ViewBag.DepartmentList = departmentManager.GetDepartmentList();
            ViewBag.SemesterList = departmentManager.GetSemesterList();
            ViewBag.CourseList = courseManager.CourseList();
            return View();
        }

        [HttpPost]
        public ActionResult Index(Course course)
        {
            ViewBag.DepartmentList = departmentManager.GetDepartmentList();
            ViewBag.SemesterList = departmentManager.GetSemesterList();
            ViewBag.CourseList = courseManager.CourseList();
            try
            {
                if (courseManager.SaveCourse(course) > 0)
                {
                    ModelState.Clear();
                    ViewBag.CourseList = courseManager.CourseList();
                    ViewBag.Message = "Save New Course Successfully";
                }
                else
                {
                    ViewBag.CourseList = courseManager.CourseList();
                    ViewBag.Errormessage = "New Course not saved successfully";
                }
            }
            catch (Exception e)
            {
                
                ViewBag.Errormessage = e.Message;
            }
            return View();
        }
	}
}