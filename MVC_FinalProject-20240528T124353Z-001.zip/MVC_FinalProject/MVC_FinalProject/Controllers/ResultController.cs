﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_FinalProject.BLL;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.Controllers
{
    public class ResultController : Controller
    {
        StudentManager studentManager = new StudentManager();
        ResultManager resultManager = new ResultManager();
        public ActionResult Index()
        {
            ViewBag.StudentList = studentManager.GetAllStudents();
            return View();
        }

        [HttpPost]
        public ActionResult Index(Result result)
        {
            ViewBag.StudentList = studentManager.GetAllStudents();
            try
            {
                if (resultManager.SaveResult(result) > 0)
                {
                    ModelState.Clear();
                   ViewBag.Message = "New Student Result Save Successfully";
                }
                else
                {
                    ViewBag.ErrorMessage = "Student Result Not Save";
                }
            }
            catch (Exception e)
            {
                ViewBag.ErrorMessage = e.Message;
            }

            return View();
        }

        public ActionResult ViewResult()
        {
            ViewBag.StudentList = studentManager.GetAllStudents();
            return View();
        }

        [HttpPost]
        public ActionResult ViewResult(Result result)
        {
            ViewBag.StudentList = studentManager.GetAllStudents();
            return View();
        }
	}
}