﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Web;
using System.Web.Mvc;
using MVC_FinalProject.BLL;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.Controllers
{
    public class StudentController : Controller
    {
        StudentManager studentManager = new StudentManager();
        DepartmentManager departmentManager = new DepartmentManager();
        public ActionResult Index()
        {
            ViewBag.DepartmentList = departmentManager.GetDepartmentList();
            ViewBag.StudentList = studentManager.GetAllStudents();
            return View();
        }

        [HttpPost]
        public ActionResult Index(Student student)
        {
            ViewBag.DepartmentList = departmentManager.GetDepartmentList();
            ViewBag.StudentList = studentManager.GetAllStudents();
            try
            {
                if (studentManager.IfEmailExist(student.StudentEmail))
                {
                    ViewBag.StudentList = studentManager.GetAllStudents();
                    ViewBag.ErrorMessage = "Sorry...Email Address Already Exist";
                }
                else
                {
                    int getYear = Convert.ToDateTime(student.RegisDate).Year;
                    student.Year = getYear;
                    int countNumber = studentManager.GetStudentCountId(student);

                    Department department = departmentManager.GetDepartmentCodeById(student.Dept_Id);
                    string deptCode = department.DepartmentCode;

                    if (countNumber > 0)
                    {
                        int regNo = countNumber + 1;
                        int updateCounter = studentManager.UpdateStudentCounter(regNo, student);
                        student.RegistrationNumber = deptCode + "-" + getYear + "-" + regNo.ToString("D3");
                    }
                    else
                    {
                        int regNo = 1;
                        student.CountNo = regNo;
                        int updateCounter = studentManager.AddStudentCounter(student);
                        student.RegistrationNumber = deptCode + "-" + getYear + "-" + regNo.ToString("D3");
                    }

                    if (studentManager.SaveNewStudent(student) > 0)
                    {
                        ModelState.Clear();
                        ViewBag.StudentList = studentManager.GetAllStudents();
                        ViewBag.Message = "Register New Student Successfully";
                    }
                    else
                    {
                        ViewBag.StudentList = studentManager.GetAllStudents();
                        ViewBag.ErrorMessage = "New Student Registration Failed";
                    }
                }
                
            }
            catch (Exception e)
            {
                ViewBag.ErrorMessage = e.Message;
            }
            return View();
        }
	}
}