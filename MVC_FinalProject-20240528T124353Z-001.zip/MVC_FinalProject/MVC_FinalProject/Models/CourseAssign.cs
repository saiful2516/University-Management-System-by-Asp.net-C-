﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVC_FinalProject.Models
{
    public class CourseAssign
    {
        [Required(ErrorMessage = "Please Select Department")]
        public int DepartmentId { set; get; }

        [DisplayName("Department Code")]
        public string DepartmentCode { set; get; }

        [DisplayName("Department Name")]
        public string DepartmentName { set; get; }

        [Required(ErrorMessage = "Please Select Teacher")]
        public int CourseId { set; get; }

        [DisplayName("Course Code")]
        [Required(ErrorMessage = "Please Select Course")]
        public string CourseCode { set; get; }

        [DisplayName("Course Name")]
        public string CourseName { set; get; }

        [DisplayName("Course Credit")]
        public double? CourseCredit { set; get; }

        [Required(ErrorMessage = "Please Select Teacher")]
        public int? TeacherId { set; get; }

        [DisplayName("Teacher Name")]
        [Required(ErrorMessage = "Please Select Teacher")]
        public string TeacherName { set; get; }

        [DisplayName("Credit To Be Taken")]
        public double? TeacherCredit { set; get; }

        public double? AssignTeacherCredit { set; get; }

        [DisplayName("Remaining Credit")]
        public double? RemainTeacherCredit { set; get; }

        public string SemesterName { set; get; }
        public int AssignCourseStatus { set; get; }
    }
}