﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_FinalProject.Models
{
    public class Semester
    {
        public int SemesterId { set; get; }
        public string SemesterName { set; get; }
    }
}