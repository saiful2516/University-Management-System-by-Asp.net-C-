﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using Microsoft.AspNet.Identity;

namespace MVC_FinalProject.Models
{
    public class Course
    {
        public int CourseId { set; get; }

        [Required(ErrorMessage = "Enter Course Code")]
        [DisplayName("Course Code")]
        [StringLength(100,MinimumLength = 5, ErrorMessage = "Course Code at least 5 characters long")]
        public string CourseCode { set; get; }

        [Required(ErrorMessage = "Enter Course Name")]
        [DisplayName("Course Name")]
        public string CourseName { set; get; }

        [Required(ErrorMessage = "Enter Course Credit")]
        [Range(.5, 5.0, ErrorMessage = "Course Credit range is from .5 - 5.0 long")]
        [DisplayName("Course Credit")]
        public double CourseCredit { set; get; }
        public string Description { set; get; }

        [DisplayName("Department")]
        [Required(ErrorMessage = "Select Department")]
        public int DepartId { set; get; }
        public string DepartmentName { set; get; }

        [DisplayName("Semester")]
        [Required(ErrorMessage = "Select Semester")]
        public int SemId { set; get; }
        public string SemesterName { set; get; }
    }
}