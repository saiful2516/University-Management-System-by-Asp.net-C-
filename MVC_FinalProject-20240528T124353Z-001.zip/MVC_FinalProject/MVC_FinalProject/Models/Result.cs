﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVC_FinalProject.Models
{
    public class Result
    {
        public int ResultId { set; get; }

        [DisplayName("Student Registration No")]
        [Required(ErrorMessage = "Please Select Student Reg No")]
        public string StudentRegNo { set; get; }

        [DisplayName("Student Name")]
        public string StudentName { set; get; }

        [DisplayName("Student Email")]
        public string Email { set; get; }

        [DisplayName("Department Name")]
        public string DepartmentName { set; get; }

        [DisplayName("Select Course")]
        [Required(ErrorMessage = "Please Select Course")]
        public int Course_Id { set; get; }
        public string CourseCode { set; get; }
        public string CourseName { set; get; }

        [Required(ErrorMessage = "Please Select Grade Letter")]
        [DisplayName("Select Grade Letter")]
        public string GradeLetter { set; get; }
    }
}