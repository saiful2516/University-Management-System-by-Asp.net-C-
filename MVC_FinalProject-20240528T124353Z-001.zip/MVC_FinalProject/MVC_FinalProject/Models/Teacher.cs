﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVC_FinalProject.Models
{
    public class Teacher
    {
        public int TeacherId { set; get; }
        [Required(ErrorMessage = "Please Enter Name")]
        [DisplayName("Teacher Name")]
        public string Name { get; set; }
        public string Address { get; set; }

        [EmailAddress(ErrorMessage = "Enter Valid Email Address")]
        [Required(ErrorMessage = "Please Enter Email Address")]
        public string Email { get; set; }
        
        [DisplayName("Contact No.")]
        public string ContactNo { get; set; }

        [DisplayName("Designation")]
        public int Desg_Id { get; set; }
        public string Designation { get; set; }

         [DisplayName("Department")]
        public int Dept_Id { set; get; }
        public string Department { get; set; }

        [Range(0,Int32.MaxValue,ErrorMessage = "Credit must be non-negative value")]
        [Required(ErrorMessage = "Please Enter Credit")]
        [DisplayName("Credit Taken")]
        public double CreditTaken { get; set; }
      


    }
}