﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVC_FinalProject.Models
{
    public class Department
    {
        
        public int DepartmentId { set; get; }

        [Required(ErrorMessage = "Enter Department Name")]
        [DisplayName("Department Name")]
        public string DepartmentName { set; get; }

        [Required(ErrorMessage = "Enter Department Code")]
        [DisplayName("Department Code")]
        [StringLength(7, MinimumLength = 2,ErrorMessage = "Code Must be 2 - 7 character long")]
        public string DepartmentCode { set; get; }

        

    }
}