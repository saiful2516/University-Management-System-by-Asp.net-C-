﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVC_FinalProject.Models
{
    public class Student
    {
        public int StudentId { set; get; }
        public string RegistrationNumber { get; set; }

        [DisplayName("Student Name")]
        [Required(ErrorMessage = "Please Enter Student Name")]
        public string StudentName { set; get; }

        [Required(ErrorMessage = "Please Enter Email Address")]
        [EmailAddress(ErrorMessage = "Please Enter Valid Email Address")]
        [DisplayName("Email")]
        public string StudentEmail { set; get; }

        [DisplayName("Contact No.")]
        public string StudentPhone { set; get; }
        
        [DisplayName("Registration Date")]
        public string RegisDate { get; set; }

        [DisplayName("Present Address")]
        public string StudentAddress { set; get; }

        [Required(ErrorMessage = "Please Select Department")]
        [DisplayName("Department")]
        public int Dept_Id { set; get; }
        public string DepartmentName { set; get; }

        // Student ID Generator Parameter
        public int SlNo { set; get; }
        public int Year { set; get; }
        public int CountNo { set; get; }

    }
}