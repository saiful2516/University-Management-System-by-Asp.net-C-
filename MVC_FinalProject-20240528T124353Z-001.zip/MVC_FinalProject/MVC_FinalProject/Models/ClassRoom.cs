﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace MVC_FinalProject.Models
{
    public class ClassRoom
    {
        public int AllocateRoomId { set; get; }

        [DisplayName("Department")]
        public int Dept_Id { set; get; }

        [DisplayName("Department")]
        public string DepartmentName { set; get; }

        [DisplayName("Course")]
        public int Course_Id { set; get; }
        public string CourseName { set; get; }
        public string CourseCode { set; get; }

        [DisplayName("Room No")]
        public int RoomNo_Id { set; get; }

        [DisplayName("Day")]
        public int DayId { set; get; }

        public string DayName { set; get; }

        [DisplayName("Time From")]
        public DateTime TimeFrom { set; get; }
        public string FromPeriod { set; get; }

        [DisplayName("Time To")]
        public DateTime TimeTo { set; get; }
        public string ToPeriod { set; get; }

        public string TimeSchedule { set; get; }
        public int? AllocationStatus { get; set; }

        public string RoomNo { set; get; }
    }
}