﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVC_FinalProject.Models
{
    public class EnrollCourse
    {
        public int EnrollId { set; get; }
        
        [DisplayName("Registration No.")]
        public string StudentRegNo { set; get; }

        [DisplayName("Student Name")]
        public string StudentName { set; get; }

        [DisplayName("Enroll Date")]
        public string EnrollDate { set; get; }
        [Required(ErrorMessage = "Please Select Course")]
        [DisplayName("Course Name")]
        public int EnrollCourseId { set; get; }
        public string CourseName { set; get; }
        public string DepartmentName { set; get; }
        public string CourseList { get; set; }

    }
}