﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.DAL
{
    public class CourseEnrollGateway:CommonGateway
    {
        public int SaveEnrollCourse(EnrollCourse enrollCourse)
        {
            Query = "INSERT INTO EnrollCourse_table VALUES(@StudentRegNo,@EnrollCourseId,@EnrollDate)";
            Command = new SqlCommand(Query, Connection);

            Command.Parameters.Clear();
            Command.Parameters.Add("StudentRegNo", SqlDbType.VarChar);
            Command.Parameters["StudentRegNo"].Value = enrollCourse.StudentRegNo;
            Command.Parameters.Add("EnrollCourseId", SqlDbType.Int);
            Command.Parameters["EnrollCourseId"].Value = enrollCourse.EnrollCourseId;
            Command.Parameters.Add("EnrollDate", SqlDbType.VarChar);
            Command.Parameters["EnrollDate"].Value = enrollCourse.EnrollDate;

            Connection.Open();
            int rowAffected = Command.ExecuteNonQuery();
            Connection.Close();
            return rowAffected;
        }

        public bool IsExistCourseEnroll(EnrollCourse enrollCourse)
        {
            Query = "SELECT * FROM EnrollCourse_table WHERE StudentRegNo=@StudentRegNo AND EnrollCourseId=@EnrollCourseId";
            Command = new SqlCommand(Query, Connection);
            Command.Parameters.Clear();
            Command.Parameters.Add("StudentRegNo", SqlDbType.VarChar);
            Command.Parameters["StudentRegNo"].Value = enrollCourse.StudentRegNo;
            Command.Parameters.Add("EnrollCourseId", SqlDbType.Int);
            Command.Parameters["EnrollCourseId"].Value = enrollCourse.EnrollCourseId;
            bool existEnrollment = false;
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                existEnrollment = true;
            }
            Connection.Close();
            return existEnrollment;
        }

        public List<EnrollCourse> AllEnrollCourseInfo()
        {
            Query = "SELECT StudentRegNo,StudentName,DepartmentName,CourseIds FROM ViewEnrollCourse_Student ";
            Command = new SqlCommand(Query, Connection);
            List<EnrollCourse> enrollCourses = new List<EnrollCourse>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    enrollCourses.Add
                    (
                        new EnrollCourse
                        {
                            StudentRegNo = Reader["StudentRegNo"].ToString(),
                            StudentName = Reader["StudentName"].ToString(),
                            DepartmentName = Reader["DepartmentName"].ToString(),
                            CourseList = Reader["CourseIds"].ToString()
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return enrollCourses;
        }
    }
}