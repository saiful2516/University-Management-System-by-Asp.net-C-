﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.DAL
{
    public class ResultGateway:CommonGateway
    {
        public bool CheckDuplicateResult(Result result)
        {
            Query = "SELECT * FROM StudentResult WHERE StudentRegNo=@StudentRegNo AND Course_Id=@Course_Id";
            Command = new SqlCommand(Query, Connection);
            Command.Parameters.Clear();
            Command.Parameters.Add("StudentRegNo", SqlDbType.VarChar);
            Command.Parameters["StudentRegNo"].Value = result.StudentRegNo;
            Command.Parameters.Add("Course_Id", SqlDbType.Int);
            Command.Parameters["Course_Id"].Value = result.Course_Id;
            bool resultExist = false;
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                resultExist = true;
            }
            Connection.Close();
            return resultExist;
        }

        public int SaveResult(Result result)
        {
            Query = "INSERT INTO StudentResult VALUES(@StudentRegNo,@Course_Id,@GradeLetter)";
            Command = new SqlCommand(Query, Connection);

            Command.Parameters.Clear();
            Command.Parameters.Add("StudentRegNo", SqlDbType.VarChar);
            Command.Parameters["StudentRegNo"].Value = result.StudentRegNo;
            Command.Parameters.Add("Course_Id", SqlDbType.Int);
            Command.Parameters["Course_Id"].Value = result.Course_Id;
            if (result.GradeLetter == "")
            {
                Command.Parameters.Add("GradeLetter", SqlDbType.VarChar);
                Command.Parameters["GradeLetter"].Value = 0;
            }
            else
            {
                Command.Parameters.Add("GradeLetter", SqlDbType.VarChar);
                Command.Parameters["GradeLetter"].Value = result.GradeLetter;
            }
            
            Connection.Open();
            int rowAffected = Command.ExecuteNonQuery();
            Connection.Close();
            return rowAffected;
        }
    }
}