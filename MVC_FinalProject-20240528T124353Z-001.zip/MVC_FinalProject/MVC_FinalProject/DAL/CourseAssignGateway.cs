﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.DAL
{
    public class CourseAssignGateway:CommonGateway
    {
        public int SaveAssignCourse(CourseAssign courseAssign)
        {
            Query = "INSERT INTO CourseAssign_tbl VALUES(@Dept_Id,@AssignTeacherId,@AssignCourseId,@AssignCourseStatus,@AssignCredit)";
            Command = new SqlCommand(Query, Connection);

            Command.Parameters.Clear();
            Command.Parameters.Add("Dept_Id", SqlDbType.Int);
            Command.Parameters["Dept_Id"].Value = courseAssign.DepartmentId;
            Command.Parameters.Add("AssignTeacherId", SqlDbType.Int);
            Command.Parameters["AssignTeacherId"].Value = courseAssign.TeacherId;
            Command.Parameters.Add("AssignCourseId", SqlDbType.Int);
            Command.Parameters["AssignCourseId"].Value = courseAssign.CourseId;
            Command.Parameters.Add("AssignCourseStatus", SqlDbType.Int);
            Command.Parameters["AssignCourseStatus"].Value = 1;
            Command.Parameters.Add("AssignCredit", SqlDbType.Decimal);
            Command.Parameters["AssignCredit"].Value = courseAssign.CourseCredit;

            Connection.Open();
            int rowAffected = Command.ExecuteNonQuery();
            Connection.Close();
            return rowAffected;
        }

        public bool IsCourseAssign(int courseId)
        {
            Query = "SELECT * FROM CourseAssign_tbl WHERE AssignCourseId=@CourseId AND AssignCourseStatus=1";
            Command = new SqlCommand(Query, Connection);
            Command.Parameters.Clear();
            Command.Parameters.Add("CourseId", SqlDbType.Int);
            Command.Parameters["CourseId"].Value = courseId;
            bool courseExist = false;
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                courseExist = true;
            }
            Connection.Close();
            return courseExist;
        }

        public List<CourseAssign> GetCourseList()
        {
            Query = "SELECT * FROM ViewCourseAssignInfo ORDER BY DepartmentName,CourseCode ASC";
            Command = new SqlCommand(Query, Connection);
            List<CourseAssign> courseAssigns = new List<CourseAssign>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    courseAssigns.Add
                    (
                        new CourseAssign
                        {
                            DepartmentName = Reader["DepartmentName"].ToString(),
                            CourseCode = Reader["CourseCode"].ToString(),
                            CourseName = Reader["CourseName"].ToString(),
                            SemesterName = Reader["SemesterName"].ToString(),
                            TeacherName = Reader["TeacherName"].ToString(),
                            AssignCourseStatus = Reader["AssignCourseStatus"].ToString() == "" ? 0 : Convert.ToInt32(Reader["AssignCourseStatus"].ToString())
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return courseAssigns;
        }

        public List<CourseAssign> SearchCourseByDepartment(int departmentId)
        {
            Query = "SELECT * FROM ViewCourseAssignInfo WHERE DepartmentId='" + departmentId + "' ORDER BY DepartmentName,CourseCode  ASC";
            Command = new SqlCommand(Query, Connection);
            List<CourseAssign> courseAssigns = new List<CourseAssign>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    courseAssigns.Add
                    (
                        new CourseAssign
                        {
                            DepartmentName = Reader["DepartmentName"].ToString(),
                            CourseCode = Reader["CourseCode"].ToString(),
                            CourseName = Reader["CourseName"].ToString(),
                            SemesterName = Reader["SemesterName"].ToString(),
                            TeacherName = Reader["TeacherName"].ToString(),
                            AssignCourseStatus = Reader["AssignCourseStatus"].ToString() == "" ? 0 : Convert.ToInt32(Reader["AssignCourseStatus"].ToString())
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return courseAssigns;
        }

        public int UnAssignAllCourse()
        {
            Query = "UPDATE CourseAssign_tbl SET AssignCourseStatus=0,AssignCredit=0 WHERE AssignCourseStatus=1";
            Command = new SqlCommand(Query, Connection);
            
            Connection.Open();
            int rowAffected = Command.ExecuteNonQuery();
            Connection.Close();
            return rowAffected;
        }

        public bool CheckExistAssignCourse()
        {
            Query = "SELECT * FROM CourseAssign_tbl WHERE AssignCourseStatus=1";
            Command = new SqlCommand(Query, Connection);
            bool courseExist = false;
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                courseExist = true;
            }
            Connection.Close();
            return courseExist;
        }
    }
}