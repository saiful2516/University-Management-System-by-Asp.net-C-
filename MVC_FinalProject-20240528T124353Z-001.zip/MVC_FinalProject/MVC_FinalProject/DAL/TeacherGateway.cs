﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.DAL
{
    public class TeacherGateway : CommonGateway
    {
      
        public int SaveTeacher(Teacher teacher)
        {

            Query = "INSERT INTO Teacher_tbl VALUES(@TeacherName,@Address,@Email,@MobileNo,@Desg_Id,@Dept_Id,@TeacherCredit)";
      
            Command = new SqlCommand(Query, Connection);

            Command.Parameters.Clear();
            Command.Parameters.Add("TeacherName", SqlDbType.VarChar);
            Command.Parameters["TeacherName"].Value = teacher.Name;
            Command.Parameters.Add("Address", SqlDbType.VarChar);
            if (teacher.Address == null)
            {
                Command.Parameters["Address"].Value = "";
            }
            else
            {
                Command.Parameters["Address"].Value = teacher.Address;
            }
            Command.Parameters.Add("Email", SqlDbType.VarChar);
            Command.Parameters["Email"].Value = teacher.Email;
            Command.Parameters.Add("MobileNo", SqlDbType.VarChar);
            if (teacher.ContactNo == null)
            {
                Command.Parameters["MobileNo"].Value = "";
            }
            else
            {
                Command.Parameters["MobileNo"].Value = teacher.ContactNo;
            }
            
            Command.Parameters.Add("Desg_Id", SqlDbType.Int);
            Command.Parameters["Desg_Id"].Value = teacher.Desg_Id;
            Command.Parameters.Add("Dept_Id", SqlDbType.Int);
            Command.Parameters["Dept_Id"].Value = teacher.Dept_Id;
            Command.Parameters.Add("TeacherCredit", SqlDbType.Decimal);
            Command.Parameters["TeacherCredit"].Value = teacher.CreditTaken;

            Connection.Open();
            int rowAffected = Command.ExecuteNonQuery();
            Connection.Close();
            return rowAffected;
        }

        public bool IsEmailExist(string Email)
        {
            Query = "SELECT * FROM Teacher_tbl WHERE Email=@Email";
            Command = new SqlCommand(Query, Connection);
            Command.Parameters.Clear();
            Command.Parameters.Add("Email", SqlDbType.VarChar);
            Command.Parameters["Email"].Value = Email;
            bool emailExist = false;
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                emailExist = true;
            }
            Connection.Close();
            return emailExist;
        }





        public List<Department> GetDepartmentList()
        {
            Query = "SELECT * FROM Department_tbl ORDER BY DepartmentCode ASC";
            Command = new SqlCommand(Query, Connection);
            List<Department> departments = new List<Department>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    departments.Add
                    (
                        new Department
                        {
                            DepartmentId = Convert.ToInt32(Reader["DepartmentId"].ToString()),
                            DepartmentName = Reader["DepartmentName"].ToString(),
                            DepartmentCode = Reader["DepartmentCode"].ToString()
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return departments;
        }

        public List<Teacher> GetDesigntatinoList()
        {
            Query = "SELECT * FROM Designation_tbl ORDER BY DesignationId ASC";
            Command = new SqlCommand(Query, Connection);
            List<Teacher> teachers = new List<Teacher>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    teachers.Add
                    (
                        new Teacher()
                        {
                            Desg_Id = Convert.ToInt32(Reader["DesignationId"].ToString()),
                            Designation = Reader["DesignationName"].ToString()
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return teachers;
        }


        public List<Teacher> GetAllTeacher()
        {
            Query = "SELECT * FROM ViewTeacherProfile ORDER BY DepartmentName,DesignationId ASC";
            Command = new SqlCommand(Query, Connection);
            List<Teacher> teachers = new List<Teacher>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    teachers.Add
                    (
                        new Teacher()
                        {
                            Name = Reader["TeacherName"].ToString(),
                            CreditTaken = Convert.ToDouble(Reader["TeacherCredit"].ToString()),
                            ContactNo = Reader["MobileNo"].ToString(),
                            Designation = Reader["DesignationName"].ToString(),
                            Department = Reader["DepartmentName"].ToString()
                            
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return teachers;
        }
    }
}