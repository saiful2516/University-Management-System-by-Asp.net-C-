﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.DAL
{
    public class DepartmentGateway:CommonGateway
    {
        public int SaveDepartment(Department department)
        {
            Query = "INSERT INTO Department_tbl VALUES(@DepartmentCode,@DepartmentName)";
            Command = new SqlCommand(Query,Connection);
            
            Command.Parameters.Clear();
            Command.Parameters.Add("DepartmentName", SqlDbType.VarChar);
            Command.Parameters["DepartmentName"].Value = department.DepartmentName;
            Command.Parameters.Add("DepartmentCode", SqlDbType.VarChar);
            Command.Parameters["DepartmentCode"].Value = department.DepartmentCode;
            Connection.Open();
            int rowAffected = Command.ExecuteNonQuery();
            Connection.Close();
            return rowAffected;
        }

        public bool IsDeptCodeExist(string departmentCode)
        {
            Query = "SELECT * FROM Department_tbl WHERE DepartmentCode=@DepartmentCode";
            Command = new SqlCommand(Query, Connection);
            Command.Parameters.Clear();
            Command.Parameters.Add("DepartmentCode", SqlDbType.VarChar);
            Command.Parameters["DepartmentCode"].Value = departmentCode;
            bool codeExist = false;
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                codeExist = true;
            }
            Connection.Close();
            return codeExist;
        }

        public bool IsDeptNameExist(string departmentName)
        {
            Query = "SELECT * FROM Department_tbl WHERE DepartmentName=@DepartmentName";
            Command = new SqlCommand(Query,Connection);
            Command.Parameters.Clear();
            Command.Parameters.Add("DepartmentName", SqlDbType.VarChar);
            Command.Parameters["DepartmentName"].Value = departmentName;
            bool nameExist = false;
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                nameExist = true;
            }
            Connection.Close();
            return nameExist;

        }

        public List<Department> GetDepartmentList()
        {
            Query = "SELECT * FROM Department_tbl ORDER BY DepartmentCode ASC";
            Command = new SqlCommand(Query, Connection);
            List<Department> departments = new List<Department>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    departments.Add
                    (
                        new Department
                        {
                            DepartmentId = Convert.ToInt32(Reader["DepartmentId"].ToString()),
                            DepartmentName = Reader["DepartmentName"].ToString(),
                            DepartmentCode = Reader["DepartmentCode"].ToString()
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return departments;
        }

        public List<Semester> GetSemesterList()
        {
            Query = "SELECT * FROM Semester_tbl ORDER BY SemesterId ASC";
            Command = new SqlCommand(Query, Connection);
            List<Semester> semesters = new List<Semester>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    semesters.Add
                    (
                        new Semester
                        {
                            SemesterId = Convert.ToInt32(Reader["SemesterId"].ToString()),
                            SemesterName = Reader["SemesterName"].ToString()
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return semesters;
        }


        public Department GetDepartmentCodeById(int deptId)
        {
            Query = "SELECT DepartmentCode FROM Department_tbl WHERE DepartmentId='" + deptId + "'";
            Command = new SqlCommand(Query, Connection);
            Connection.Open();
            Department department = null;
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    department = new Department();
                    department.DepartmentCode = Reader["DepartmentCode"].ToString();
                }
                Reader.Close();
            }
            Connection.Close();
            return department;
        }
    }
}
