﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.DAL
{
    public class CourseGateway:CommonGateway
    {
        public int SaveCourse(Course course)
        {
            Query = "INSERT INTO Course_tbl VALUES(@CourseCode,@CourseName,@CourseCredit,@CourseDesc,@Dept_Id,@Sem_Id)";
            //Query = "INSERT INTO Course_tbl VALUES('"+course.CourseCode+"','"+course.CourseName+"',"+course.CourseCredit+",'"+course.Description+"',"+course.DepartId+","+course.SemId+")";
            Command = new SqlCommand(Query, Connection);

            Command.Parameters.Clear();
            Command.Parameters.Add("CourseCode", SqlDbType.VarChar);
            Command.Parameters["CourseCode"].Value = course.CourseCode;
            Command.Parameters.Add("CourseName", SqlDbType.VarChar);
            Command.Parameters["CourseName"].Value = course.CourseName;
            Command.Parameters.Add("CourseCredit", SqlDbType.Decimal);
            Command.Parameters["CourseCredit"].Value = course.CourseCredit;
            Command.Parameters.Add("CourseDesc", SqlDbType.VarChar);
            if (course.Description == null)
            {
                Command.Parameters["CourseDesc"].Value = "";
            }
            else
            {
                Command.Parameters["CourseDesc"].Value = course.Description;
            }
            
            Command.Parameters.Add("Dept_Id", SqlDbType.Int);
            Command.Parameters["Dept_Id"].Value = course.DepartId;
            Command.Parameters.Add("Sem_Id", SqlDbType.Int);
            Command.Parameters["Sem_Id"].Value = course.SemId;

            Connection.Open();
            int rowAffected = Command.ExecuteNonQuery();
            Connection.Close();
            return rowAffected;
        }

        public bool IsCourseNameExist(string courseName)
        {
            Query = "SELECT * FROM Course_tbl WHERE CourseName=@CourseName";
            Command = new SqlCommand(Query, Connection);
            Command.Parameters.Clear();
            Command.Parameters.Add("CourseName", SqlDbType.VarChar);
            Command.Parameters["CourseName"].Value = courseName;
            bool nameExist = false;
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                nameExist = true;
            }
            Connection.Close();
            return nameExist;
        }

        public bool IsCourseCodeExist(string courseCode)
        {
            Query = "SELECT * FROM Course_tbl WHERE CourseCode=@CourseCode";
            Command = new SqlCommand(Query, Connection);
            Command.Parameters.Clear();
            Command.Parameters.Add("CourseCode", SqlDbType.VarChar);
            Command.Parameters["CourseCode"].Value = courseCode;
            bool codeExist = false;
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                codeExist = true;
            }
            Connection.Close();
            return codeExist;
        }

        public List<Course> CourseList()
        {
            Query = "SELECT * FROM ViewCourse_Dept_Sem ORDER BY DepartmentName,DepartmentId ASC";
            Command = new SqlCommand(Query, Connection);
            List<Course> courses = new List<Course>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    courses.Add
                    (
                        new Course
                        {
                            CourseId = Convert.ToInt32(Reader["CourseId"].ToString()),
                            CourseCode = Reader["CourseCode"].ToString(),
                            CourseName = Reader["CourseName"].ToString(),
                            CourseCredit = Convert.ToDouble(Reader["CourseCredit"].ToString()),
                            DepartmentName = Reader["DepartmentName"].ToString(),
                            SemesterName = Reader["SemesterName"].ToString()
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return courses;
        }
    }
}