﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.DAL
{
    public class DependentDropDownGateway:CommonGateway
    {
        public List<AssignCourseWithTeacher> GetTecherListByDepartmentId(int departmentId)
        {
            Query = "SELECT TeacherId,TeacherName FROM AssignCourseWithTeacher WHERE DepartmentId = '" + departmentId + "' GROUP BY TeacherId,TeacherName";
            Command = new SqlCommand(Query, Connection);
            List<AssignCourseWithTeacher> assignCourseWithTeachers = new List<AssignCourseWithTeacher>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    assignCourseWithTeachers.Add
                    (
                        new AssignCourseWithTeacher
                        {
                            TeacherId = Reader["TeacherId"].ToString()==""?(int?) null:Convert.ToInt32(Reader["TeacherId"].ToString()),
                            TeacherName = Reader["TeacherName"].ToString()
                            // TeacherCredit = Convert.ToDouble(Reader["TeacherCredit"].ToString())

                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return assignCourseWithTeachers;
        }

        public List<Course> GetCourseListByDepartmentId(int departmentId)
        {
            Query = "SELECT CourseId,CourseCode,CourseName FROM Course_tbl WHERE Dept_Id = '" + departmentId + "' GROUP BY CourseId,CourseCode,CourseName";
            Command = new SqlCommand(Query, Connection);
            List<Course> courses = new List<Course>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    courses.Add
                    (
                        new Course
                        {
                            CourseId = Convert.ToInt32(Reader["CourseId"].ToString()),
                            CourseCode = Reader["CourseCode"].ToString(),
                            CourseName = Reader["CourseName"].ToString()
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return courses;
        }
        public List<AssignCourseWithTeacher> GetAssignCourseListByDepartmentId(int departmentId)
        {
            Query = "SELECT CourseId,CourseCode FROM AssignCourseWithTeacher WHERE DepartmentId = '" + departmentId + "' GROUP BY CourseId,CourseCode";
            Command = new SqlCommand(Query, Connection);
            List<AssignCourseWithTeacher> assignCourseWithTeachers = new List<AssignCourseWithTeacher>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    assignCourseWithTeachers.Add
                    (
                        new AssignCourseWithTeacher
                        {
                            //DepartmentId = Convert.ToInt32(Reader["DepartmentId"].ToString()),
                            //DepartmentName = Reader["DepartmentName"].ToString(),
                            //DepartmentCode = Reader["DepartmentCode"].ToString(),
                            CourseId = Reader["CourseId"].ToString()==""?(int?) null:Convert.ToInt32(Reader["CourseId"].ToString()),
                            CourseCode = Reader["CourseCode"].ToString(),
                            //CourseName = Reader["CourseName"].ToString()
                            //CourseCredit = Convert.ToDouble(Reader["CourseCredit"].ToString())
                            

                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return assignCourseWithTeachers;
        }

        public List<AssignCourseWithTeacher> GetTeacherCreditByTeacherId(int teacherId)
        {
            Query = "SELECT TotalTeacherCredit,TotalAssignCredit,(TotalTeacherCredit-TotalAssignCredit) as RemainigCredit FROM ViewTeacherCreditList WHERE TeacherId = '" + teacherId + "'";
            Command = new SqlCommand(Query, Connection);
            List<AssignCourseWithTeacher> assignCourseWithTeachers = new List<AssignCourseWithTeacher>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    assignCourseWithTeachers.Add
                    (
                        new AssignCourseWithTeacher
                        {
                            TeacherCredit = Reader["TotalTeacherCredit"].ToString() == "" ? 0 : Convert.ToDouble(Reader["TotalTeacherCredit"].ToString()),
                            AssignTeacherCredit = Reader["TotalAssignCredit"].ToString() == "" ? 0 : Convert.ToDouble(Reader["TotalAssignCredit"].ToString()),
                           // RemainTeacherCredit = (TeacherCredit - AssignTeacherCredit)
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return assignCourseWithTeachers;
        }

        public List<Course> GetCourseInfoByCourseId(int courseId)
        {
            Query = "SELECT CourseId,CourseName,CourseCredit FROM Course_tbl WHERE CourseId = '" + courseId + "'";
            Command = new SqlCommand(Query, Connection);
            List<Course> allCourses = new List<Course>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    allCourses.Add
                    (
                        new Course
                        {
                            CourseId = Convert.ToInt32(Reader["CourseId"].ToString()),
                            CourseName = Reader["CourseName"].ToString(),
                            CourseCredit = Reader["CourseCredit"].ToString() == "" ? 0 : Convert.ToDouble(Reader["CourseCredit"].ToString())
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return allCourses;
        }

        public List<Student> GetStudentInfoByRegNo(string registrationNo)
        {
            Query = "SELECT * FROM ViewStudentWithDepartment WHERE RegistrationNumber = '" + registrationNo + "'";
            Command = new SqlCommand(Query, Connection);
            List<Student> students = new List<Student>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    students.Add
                    (
                        new Student
                        {
                            Dept_Id = Convert.ToInt32(Reader["DepartmentId"].ToString()),
                            DepartmentName = Reader["DepartmentName"].ToString(),
                            StudentName = Reader["StudentName"].ToString(),
                            StudentEmail = Reader["StudentEmail"].ToString(),
                            RegistrationNumber = Reader["RegistrationNumber"].ToString()
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return students;
        }

        public List<EnrollCourse> GetStudentCourseIdByRegNo(string registrationNo)
        {
            Query = "SELECT * FROM ViewStudentWithCourse WHERE RegistrationNumber = '" + registrationNo + "'";
            Command = new SqlCommand(Query, Connection);
            List<EnrollCourse> enrollCourses = new List<EnrollCourse>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    enrollCourses.Add
                    (
                        new EnrollCourse
                        {
                            EnrollCourseId = Reader["CourseId"].ToString() == "" ? 0 : Convert.ToInt32(Reader["CourseId"].ToString()),
                            CourseName = Reader["CourseName"].ToString() == "" ? "" : Reader["CourseName"].ToString(),
                            StudentName = Reader["StudentName"].ToString(),
                            StudentRegNo = Reader["RegistrationNumber"].ToString()
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return enrollCourses;
        }

        public List<EnrollCourse> GetDepartmentCourseIdByStudentRegNo(string registrationNo)
        {
            Query = "SELECT * FROM ViewStudentWith_DeptCourse WHERE RegistrationNumber = '" + registrationNo + "'";
            Command = new SqlCommand(Query, Connection);
            List<EnrollCourse> enrollCourses = new List<EnrollCourse>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    enrollCourses.Add
                    (
                        new EnrollCourse
                        {
                            EnrollCourseId = Reader["CourseId"].ToString() == "" ? 0 : Convert.ToInt32(Reader["CourseId"].ToString()),
                            CourseName = Reader["CourseName"].ToString() == "" ? "" : Reader["CourseName"].ToString()
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return enrollCourses;
        }

        public List<Result> GetResultByRegNo(string registrationNo)
        {
            Query = "SELECT * FROM ViewResultWithCourseInfo WHERE RegistrationNumber = '" + registrationNo + "'";
            Command = new SqlCommand(Query, Connection);
            List<Result> results = new List<Result>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    results.Add
                    (
                        new Result
                        {
                            CourseCode = Reader["CourseCode"].ToString() == "" ? "" : Reader["CourseCode"].ToString(),
                            CourseName = Reader["CourseName"].ToString() == "" ? "" : Reader["CourseName"].ToString(),
                            GradeLetter = Reader["GradeLetter"].ToString() == "" ? "Not Graded Yet" : Reader["GradeLetter"].ToString()
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return results;
        }
    }
}