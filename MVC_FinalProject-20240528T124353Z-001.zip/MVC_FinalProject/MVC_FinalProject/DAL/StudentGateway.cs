﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.DAL
{
    public class StudentGateway:CommonGateway
    {
        public List<Student> GetAllStudents()
        {
            Query = "SELECT * FROM ViewStudentWithDepartment ORDER BY DepartmentName,DepartmentId ASC";
            Command = new SqlCommand(Query, Connection);
            List<Student> students = new List<Student>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    students.Add
                    (
                        new Student
                        {
                            StudentId = Convert.ToInt32(Reader["StudentId"].ToString()),
                            RegistrationNumber = Reader["RegistrationNumber"].ToString(),
                            StudentName = Reader["StudentName"].ToString(),
                            StudentEmail = Reader["StudentEmail"].ToString(),
                            DepartmentName = Reader["DepartmentName"].ToString()
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return students;
        }

        public int SaveNewStudent(Student student)
        {
            Query = "INSERT INTO Student_tbl VALUES(@RegistrationNumber,@StudentName,@StudentEmail,@StudentPhone,@RegisDate,@StudentAddress,@Dept_Id)";
            Command = new SqlCommand(Query, Connection);

            Command.Parameters.Clear();
            Command.Parameters.Add("RegistrationNumber", SqlDbType.VarChar);
            Command.Parameters["RegistrationNumber"].Value = student.RegistrationNumber;
            Command.Parameters.Add("StudentName", SqlDbType.VarChar);
            Command.Parameters["StudentName"].Value = student.StudentName;
            Command.Parameters.Add("StudentEmail", SqlDbType.VarChar);
            Command.Parameters["StudentEmail"].Value = student.StudentEmail;
            Command.Parameters.Add("StudentPhone", SqlDbType.VarChar);
            Command.Parameters["StudentPhone"].Value = student.StudentPhone == null ? "" : student.StudentPhone;
            Command.Parameters.Add("RegisDate", SqlDbType.VarChar);
            Command.Parameters["RegisDate"].Value = student.RegisDate;
            Command.Parameters.Add("StudentAddress", SqlDbType.VarChar);
            Command.Parameters["StudentAddress"].Value = student.StudentAddress == null ? "" : student.StudentAddress;
            Command.Parameters.Add("Dept_Id", SqlDbType.Int);
            Command.Parameters["Dept_Id"].Value = student.Dept_Id;
            Connection.Open();
            int rowAffected = Command.ExecuteNonQuery();
            Connection.Close();
            return rowAffected;
        }

        public bool IfEmailExist(string studentEmail)
        {
            Query = "SELECT * FROM Student_tbl WHERE StudentEmail=@StudentEmail";
            Command = new SqlCommand(Query, Connection);
            Command.Parameters.Clear();
            Command.Parameters.Add("StudentEmail", SqlDbType.VarChar);
            Command.Parameters["StudentEmail"].Value = studentEmail;
            bool codeExist = false;
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                codeExist = true;
            }
            Connection.Close();
            return codeExist;
        }

        public int GetStudentCountId(Student student)
        {
            Query = "SELECT CountNo FROM IdCounter_tbl WHERE Dept_Id='" + student.Dept_Id + "' AND Year='" + student.Year + "'";
            Command = new SqlCommand(Query, Connection);
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    student.CountNo = Convert.ToInt32(Reader["CountNo"].ToString());
                }
                Reader.Close();
            }
            Connection.Close();
            return student.CountNo;
        }

        public int UpdateStudentCounter(int regNo, Student student)
        {
            Query = "UPDATE IdCounter_tbl SET CountNo='" + regNo + "' WHERE Dept_Id='" + student.Dept_Id + "' AND Year='" + student.Year + "'";
            Command = new SqlCommand(Query, Connection);

            Connection.Open();
            int rowAffect = Command.ExecuteNonQuery();
            Connection.Close();
            return rowAffect;
        }

        public int AddStudentCounter(Student student)
        {
            Query = "INSERT INTO IdCounter_tbl VALUES(@Dept_Id,@Year,@CountNo)";
            Command = new SqlCommand(Query, Connection);

            Command.Parameters.Clear();
            Command.Parameters.Add("Dept_Id", SqlDbType.Int);
            Command.Parameters["Dept_Id"].Value = student.Dept_Id;
            Command.Parameters.Add("Year", SqlDbType.VarChar);
            Command.Parameters["Year"].Value = student.Year;
            Command.Parameters.Add("CountNo", SqlDbType.VarChar);
            Command.Parameters["CountNo"].Value = student.CountNo;
            Connection.Open();
            int rowAffected = Command.ExecuteNonQuery();
            Connection.Close();
            return rowAffected;
        }
    }
}