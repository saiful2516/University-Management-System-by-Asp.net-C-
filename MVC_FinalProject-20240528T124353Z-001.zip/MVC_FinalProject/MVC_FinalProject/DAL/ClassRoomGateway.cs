﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using MVC_FinalProject.Models;

namespace MVC_FinalProject.DAL
{
    public class ClassRoomGateway:CommonGateway
    {
        public List<ClassRoom> RoomList()
        {
            Query = "SELECT * FROM Room_tbl ORDER BY RoomId ASC";
            Command = new SqlCommand(Query, Connection);
            List<ClassRoom> classRooms = new List<ClassRoom>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    classRooms.Add
                    (
                        new ClassRoom
                        {
                            RoomNo_Id = Convert.ToInt32(Reader["RoomId"].ToString()),
                            RoomNo = Reader["RoomNo"].ToString()
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return classRooms;
        }

        public int AllocateNewClassRoom(ClassRoom classRoom)
        {
            Query = "INSERT INTO AllocateRoom_tbl VALUES(@Dept_Id,@Course_Id,@RoomNo_Id,@DayId,CONVERT(VARCHAR(5),CONVERT(DATETIME, @TimeFrom, 0), 108),CONVERT(VARCHAR(5),CONVERT(DATETIME, @TimeTo, 0), 108),1)";
            Command = new SqlCommand(Query, Connection);

            Command.Parameters.Clear();
            Command.Parameters.Add("Dept_Id", SqlDbType.Int);
            Command.Parameters["Dept_Id"].Value = classRoom.Dept_Id;
            Command.Parameters.Add("Course_Id", SqlDbType.Int);
            Command.Parameters["Course_Id"].Value = classRoom.Course_Id;
            Command.Parameters.Add("RoomNo_Id", SqlDbType.Int);
            Command.Parameters["RoomNo_Id"].Value = classRoom.RoomNo_Id;
            Command.Parameters.Add("DayId", SqlDbType.Int);
            Command.Parameters["DayId"].Value = classRoom.DayId;
            Command.Parameters.Add("TimeFrom", SqlDbType.DateTime);
            Command.Parameters["TimeFrom"].Value = classRoom.TimeFrom;
            Command.Parameters.Add("TimeTo", SqlDbType.DateTime);
            Command.Parameters["TimeTo"].Value = classRoom.TimeTo;
            Connection.Open();
            int rowAffected = Command.ExecuteNonQuery();
            Connection.Close();
            return rowAffected;
        }

        public bool CheckDuplicateAllocation(ClassRoom classRoom)
        {
            Query = "SELECT * FROM AllocateRoom_tbl WHERE Dept_Id=@Dept_Id AND Course_Id=@Course_Id AND RoomNo_Id=@RoomNo_Id AND DayId=@DayId AND TimeFrom=CONVERT(VARCHAR(5),CONVERT(DATETIME, @TimeFrom, 0), 108) AND TimeTo=CONVERT(VARCHAR(5),CONVERT(DATETIME, @TimeTo, 0), 108) AND AllocationStatus=1";
            Command = new SqlCommand(Query, Connection);
            Command.Parameters.Clear();
            Command.Parameters.Add("Dept_Id", SqlDbType.Int);
            Command.Parameters["Dept_Id"].Value = classRoom.Dept_Id;
            Command.Parameters.Add("Course_Id", SqlDbType.Int);
            Command.Parameters["Course_Id"].Value = classRoom.Course_Id;
            Command.Parameters.Add("RoomNo_Id", SqlDbType.Int);
            Command.Parameters["RoomNo_Id"].Value = classRoom.RoomNo_Id;
            Command.Parameters.Add("DayId", SqlDbType.Int);
            Command.Parameters["DayId"].Value = classRoom.DayId;
            Command.Parameters.Add("TimeFrom", SqlDbType.VarChar);
            Command.Parameters["TimeFrom"].Value = classRoom.TimeFrom;
            Command.Parameters.Add("TimeTo", SqlDbType.VarChar);
            Command.Parameters["TimeTo"].Value = classRoom.TimeTo;
            bool duplicateExist = false;
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                duplicateExist = true;
            }
            Connection.Close();
            return duplicateExist;
        }

        public bool CheckCourseDuplicationByDay(ClassRoom classRoom)
        {
            Query = "SELECT * FROM AllocateRoom_tbl WHERE Course_Id=@Course_Id AND RoomNo_Id=@RoomNo_Id AND DayId=@DayId AND AllocationStatus=1";
            Command = new SqlCommand(Query, Connection);
            Command.Parameters.Clear();
            Command.Parameters.Add("Course_Id", SqlDbType.Int);
            Command.Parameters["Course_Id"].Value = classRoom.Course_Id;
            Command.Parameters.Add("RoomNo_Id", SqlDbType.Int);
            Command.Parameters["RoomNo_Id"].Value = classRoom.RoomNo_Id;
            Command.Parameters.Add("DayId", SqlDbType.Int);
            Command.Parameters["DayId"].Value = classRoom.DayId;
            bool duplicateExist = false;
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                duplicateExist = true;
            }
            Connection.Close();
            return duplicateExist;
        }

        public bool CheckRoomDayTimeDuplication(ClassRoom classRoom)
        {
            Query = "SELECT * FROM AllocateRoom_tbl WHERE RoomNo_Id=@RoomNo_Id AND DayId=@DayId AND TimeFrom = CONVERT(VARCHAR(5),CONVERT(DATETIME, @TimeFrom, 0), 108) AND TimeTo = CONVERT(VARCHAR(5),CONVERT(DATETIME, @TimeTo, 0), 108) AND AllocationStatus=1";
            Command = new SqlCommand(Query, Connection);
            Command.Parameters.Clear();
            Command.Parameters.Add("RoomNo_Id", SqlDbType.Int);
            Command.Parameters["RoomNo_Id"].Value = classRoom.RoomNo_Id;
            Command.Parameters.Add("DayId", SqlDbType.Int);
            Command.Parameters["DayId"].Value = classRoom.DayId;
            Command.Parameters.Add("TimeFrom", SqlDbType.VarChar);
            Command.Parameters["TimeFrom"].Value = classRoom.TimeFrom;
            Command.Parameters.Add("TimeTo", SqlDbType.VarChar);
            Command.Parameters["TimeTo"].Value = classRoom.TimeTo;
            bool duplicateExist = false;
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                duplicateExist = true;
            }
            Connection.Close();
            return duplicateExist;
        }

        public bool CheckDayTimeDuration(ClassRoom classRoom)
        {
            Query = "SELECT * FROM AllocateRoom_tbl WHERE AllocationStatus=1 AND RoomNo_Id=@RoomNo_Id AND DayId=@DayId AND (TimeFrom BETWEEN CONVERT(VARCHAR(5),CONVERT(DATETIME, @TimeFrom, 0), 108) AND CONVERT(VARCHAR(5),CONVERT(DATETIME, @TimeTo, 0), 108) or TimeTo BETWEEN CONVERT(VARCHAR(5),CONVERT(DATETIME, @TimeFrom, 0), 108) AND CONVERT(VARCHAR(5),CONVERT(DATETIME, @TimeTo, 0), 108))";
            Command = new SqlCommand(Query, Connection);
            Command.Parameters.Clear();
            Command.Parameters.Add("RoomNo_Id", SqlDbType.Int);
            Command.Parameters["RoomNo_Id"].Value = classRoom.RoomNo_Id;
            Command.Parameters.Add("DayId", SqlDbType.Int);
            Command.Parameters["DayId"].Value = classRoom.DayId;
            Command.Parameters.Add("TimeFrom", SqlDbType.VarChar);
            Command.Parameters["TimeFrom"].Value = classRoom.TimeFrom;
            Command.Parameters.Add("TimeTo", SqlDbType.VarChar);
            Command.Parameters["TimeTo"].Value = classRoom.TimeTo;
            bool duplicateExist = false;
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                duplicateExist = true;
            }
            Connection.Close();
            return duplicateExist;
        }

        public List<ClassRoom> TimeScheduleList()
        {
            Query = "SELECT CourseId,CourseCode,CourseName,AllocationStatus,timeschedule=STUFF((SELECT DISTINCT ' '+CAST(timeschedule AS VARCHAR(MAX)) FROM ViewAllocateRoomWithCourse t2 WHERE t2.CourseId = t1.CourseId AND t2.AllocationStatus =1 FOR XML PATH('') ),1,1,'' ) FROM ViewAllocateRoomWithCourse t1 GROUP BY CourseId,CourseCode,CourseName,AllocationStatus ORDER BY CourseId ASC";

            Command = new SqlCommand(Query, Connection);
            List<ClassRoom> classRooms = new List<ClassRoom>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    classRooms.Add
                    (
                        new ClassRoom
                        {
                            Course_Id = Convert.ToInt32(Reader["CourseId"].ToString()),
                            CourseCode = Reader["CourseCode"].ToString(),
                            CourseName = Reader["CourseName"].ToString(),
                            AllocationStatus = Reader["AllocationStatus"].ToString() == "" ? 0 : Convert.ToInt32(Reader["AllocationStatus"].ToString()),
                            TimeSchedule = Reader["timeschedule"].ToString()
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return classRooms;
        }

        public List<ClassRoom> GetAllocateRoomInfoByDepartment(int departmentId)
        {
            Query = "SELECT CourseId,CourseCode,CourseName,AllocationStatus,timeschedule=STUFF((SELECT DISTINCT ' '+CAST(timeschedule AS VARCHAR(MAX)) FROM ViewAllocateRoomWithCourse t2 WHERE t2.CourseId = t1.CourseId AND t2.AllocationStatus =1 FOR XML PATH('') ),1,1,'' ) FROM ViewAllocateRoomWithCourse t1 WHERE DepartmentId= '" + departmentId + "'GROUP BY CourseId,CourseCode,CourseName,AllocationStatus  ORDER BY CourseId ASC";

            Command = new SqlCommand(Query, Connection);
            List<ClassRoom> classRooms = new List<ClassRoom>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    classRooms.Add
                    (
                        new ClassRoom
                        {
                            Course_Id = Convert.ToInt32(Reader["CourseId"].ToString()),
                            CourseCode = Reader["CourseCode"].ToString(),
                            CourseName = Reader["CourseName"].ToString(),
                            AllocationStatus = Reader["AllocationStatus"].ToString() == "" ? 0 : Convert.ToInt32(Reader["AllocationStatus"].ToString()),
                            TimeSchedule = Reader["timeschedule"].ToString()
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return classRooms;
        }

        public int UnassignClassRoom()
        {
            Query = "UPDATE AllocateRoom_tbl SET AllocationStatus=0 WHERE AllocationStatus=1";
            Command = new SqlCommand(Query, Connection);

            Connection.Open();
            int rowAffected = Command.ExecuteNonQuery();
            Connection.Close();
            return rowAffected;
        }

        public List<ClassRoom> DayList()
        {
            Query = "SELECT * FROM Day_tbl ORDER BY DId ASC";
            Command = new SqlCommand(Query, Connection);
            List<ClassRoom> classRooms = new List<ClassRoom>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                while (Reader.Read())
                {
                    classRooms.Add
                    (
                        new ClassRoom
                        {
                            DayId = Convert.ToInt32(Reader["DId"].ToString()),
                            DayName = Reader["DayName"].ToString()
                        }
                    );

                }
                Reader.Close();
            }
            Connection.Close();
            return classRooms;
        }

        
    }
}